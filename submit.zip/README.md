# Gomoku

#### Gomoku, also known as Gobang and Five-in-a-row is a two-player board game played traditionally
#### on a 15 x 15 board. Players take alternating turns to place black or white pieces in empty blocks
#### on the grid. A player wins the game by placing 5 of their pieces in an unbroken line, horizontally,
#### vertically or diagonally.
